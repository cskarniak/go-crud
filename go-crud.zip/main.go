package main

import (
    "log"
    "net/http"
    "example.com/go-crud/config"
    "github.com/gin-gonic/gin"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
)

// Article est notre modèle de données
type Article struct {
    ID      uint   `gorm:"primaryKey"`
    Title   string `form:"title" binding:"required"`
    Content string `form:"content" binding:"required"`
}

func main() {
    // 1. Charge la configuration depuis config/config.yaml
    config.Init()

    // 2. Passe en mode release pour désactiver le debug
    gin.SetMode(gin.ReleaseMode)

    // 3. Crée l’engine Gin avec logger et recovery
    r := gin.New()
    r.Use(gin.Logger(), gin.Recovery())

    // 4. Configure les proxies de confiance depuis la config
    if err := r.SetTrustedProxies(config.Conf.Server.TrustedProxies); err != nil {
        log.Fatalf("⚠️ Erreur proxies : %v", err)
    }

    // 5. Ouvre la base SQLite dont le chemin vient de la config
    db, err := gorm.Open(sqlite.Open(config.Conf.Database.Path), &gorm.Config{})
    if err != nil {
        log.Fatalf("⚠️ Échec connexion BDD : %v", err)
    }
    db.AutoMigrate(&Article{})

    // 6. Statics & templates
    r.Static("/assets", "./assets")
    r.LoadHTMLGlob("templates/*")

    // 7. Routes CRUD
    r.GET("/", func(c *gin.Context) {
        var articles []Article
        db.Find(&articles)
        c.HTML(http.StatusOK, "layout.html", gin.H{
            "articles": articles,
        })
    })

    r.GET("/articles/new", func(c *gin.Context) {
        c.HTML(http.StatusOK, "layout.html", gin.H{
            "showCreate": true,
        })
    })

    r.POST("/articles", func(c *gin.Context) {
        var form Article
        if err := c.ShouldBind(&form); err != nil {
            c.HTML(http.StatusBadRequest, "layout.html", gin.H{
                "showCreate": true,
                "error":      err.Error(),
            })
            return
        }
        db.Create(&form)
        c.Redirect(http.StatusFound, "/")
    })

    r.GET("/articles/edit/:id", func(c *gin.Context) {
        var article Article
        if err := db.First(&article, c.Param("id")).Error; err != nil {
            c.String(http.StatusNotFound, "Article non trouvé")
            return
        }
        c.HTML(http.StatusOK, "layout.html", gin.H{
            "showEdit": true,
            "article":  article,
        })
    })

    r.POST("/articles/update/:id", func(c *gin.Context) {
        var article Article
        if err := db.First(&article, c.Param("id")).Error; err != nil {
            c.String(http.StatusNotFound, "Article non trouvé")
            return
        }
        if err := c.ShouldBind(&article); err != nil {
            c.HTML(http.StatusBadRequest, "layout.html", gin.H{
                "showEdit": true,
                "error":    err.Error(),
                "article":  article,
            })
            return
        }
        db.Save(&article)
        c.Redirect(http.StatusFound, "/")
    })

    r.POST("/articles/delete/:id", func(c *gin.Context) {
        db.Delete(&Article{}, c.Param("id"))
        c.Redirect(http.StatusFound, "/")
    })

    // 8. Démarre le serveur sur le port configuré
    addr := ":" + config.Conf.Server.Port
    log.Printf("🚀 Serveur démarré sur http://localhost%s", addr)
    if err := r.Run(addr); err != nil {
        log.Fatalf("⚠️ Échec démarrage serveur : %v", err)
    }
}
