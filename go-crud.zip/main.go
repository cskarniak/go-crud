package main

import (
    "fmt"
    "log"
    "path/filepath"

    "github.com/gin-gonic/gin"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"

    // Modules importés depuis example.com/go-crud
    "example.com/go-crud/config"
    "example.com/go-crud/config/entities"
    "example.com/go-crud/internal/crud"
)

func main() {
    // 1. Charger la configuration
    cfg := config.Load()

    // 2. Initialiser Gin en mode Release et configurer les proxies de confiance
    gin.SetMode(gin.ReleaseMode)
    router := gin.Default()
    if err := router.SetTrustedProxies(cfg.TrustedProxies); err != nil {
        log.Fatalf("Impossible de configurer les proxies de confiance : %v", err)
    }

    // 3. Initialiser la base de données SQLite
    dbPath := fmt.Sprintf("%s/%s", cfg.DatabaseDir, cfg.DatabaseName)
    db, err := gorm.Open(sqlite.Open(dbPath), &gorm.Config{})
    if err != nil {
        log.Fatalf("Échec de la connexion à la base SQLite (%s) : %v", dbPath, err)
    }

    // 4. Charger toutes les entités et enregistrer les routes CRUD
    yamlFiles, err := filepath.Glob("config/entities/*.yaml")
    if err != nil {
        log.Fatalf("Erreur lors de la recherche des fichiers YAML d'entité : %v", err)
    }

    for _, file := range yamlFiles {
        ec, err := entities.LoadEntityConfig(file)
        if err != nil {
            log.Fatalf("Échec du parsing de %s : %v", file, err)
        }
        crud.RegisterEntity(router, db, ec)
    }

    // 5. Démarrer le serveur HTTP
    addr := fmt.Sprintf("%s:%s", cfg.ServerHost, cfg.ServerPort)
    log.Printf("Démarrage du serveur sur %s...", addr)
    if err := router.Run(addr); err != nil {
        log.Fatalf("Échec du démarrage du serveur : %v", err)
    }
}
