// config/config.go
package config

import (
    "io/ioutil"
    "log"

    "gopkg.in/yaml.v3"
)

// Server contient la config du serveur
type Server struct {
    Port           string   `yaml:"port"`
    TrustedProxies []string `yaml:"trusted_proxies"`
}

// Database contient la config de la BDD
type Database struct {
    Path string `yaml:"path"`
}

// Conf est la config globale exposée
var Conf struct {
    Server   Server   `yaml:"server"`
    Database Database `yaml:"database"`
}

// Init charge config/config.yaml
func Init() {
    data, err := ioutil.ReadFile("config/config.yaml")
    if err != nil {
        log.Fatalf("⚠️ Impossible de lire config/config.yaml : %v", err)
    }
    if err := yaml.Unmarshal(data, &Conf); err != nil {
        log.Fatalf("⚠️ Impossible de parser config/config.yaml : %v", err)
    }
}
