// go-crud/internal/crud/routes.go
package crud

import (
    "net/http"
    "strconv"

    "github.com/gin-gonic/gin"
    "gorm.io/gorm"

    "example.com/go-crud/config/entities" // ajustez selon votre go.mod
)

// RegisterEntity génère les 5 routes CRUD pour une entité
func RegisterEntity(r *gin.Engine, db *gorm.DB, ec *entities.EntityConfig) {
    prefix := "/" + ec.Name

    // LIST
    r.GET(prefix, func(c *gin.Context) {
        page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
        pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", strconv.Itoa(ec.DefaultPageSize)))
        sortField := c.DefaultQuery("sort", ec.DefaultSortField)
        sortOrder := c.DefaultQuery("order", ec.DefaultSortOrder)

        var data []map[string]interface{}
        db.Table(ec.Table).
            Order(sortField + " " + sortOrder).
            Offset((page-1)*pageSize).
            Limit(pageSize).
            Find(&data)

        c.HTML(http.StatusOK, "index.html", gin.H{
            "Entity":    ec,
            "Columns":   ec.List.Columns,
            "Data":      data,
            "Page":      page,
            "PageSize":  pageSize,
            "SortField": sortField,
            "SortOrder": sortOrder,
        })
    })

    // NEW
    r.GET(prefix+"/new", func(c *gin.Context) {
        c.HTML(http.StatusOK, "form.html", gin.H{
            "Entity":    ec,
            "Mode":      "new",
            "DataRow":   map[string]interface{}{},  // form vide
            "Page":      c.Query("page"),
            "PageSize":  c.Query("pageSize"),
            "SortField": c.Query("sort"),
            "SortOrder": c.Query("order"),
        })
    })

    // CREATE
    r.POST(prefix, func(c *gin.Context) {
        vals := map[string]interface{}{}
        for _, f := range ec.Fields {
            vals[f.Name] = c.PostForm(f.Name)
        }
        db.Table(ec.Table).Create(vals)
        c.Redirect(http.StatusSeeOther, prefix)
    })

    // EDIT
    r.GET(prefix+"/edit/:id", func(c *gin.Context) {
        id := c.Param("id")

        var dataRow map[string]interface{}
        if err := db.Table(ec.Table).
            Where("id = ?", id).
            Take(&dataRow).
            Error; err != nil {
            c.String(http.StatusNotFound, "Enregistrement non trouvé")
            return
        }

        c.HTML(http.StatusOK, "form.html", gin.H{
            "Entity":    ec,
            "Mode":      "edit",
            "DataRow":   dataRow,  // map pré-remplie
            "Page":      c.Query("page"),
            "PageSize":  c.Query("pageSize"),
            "SortField": c.Query("sort"),
            "SortOrder": c.Query("order"),
        })
    })

    // UPDATE
    r.POST(prefix+"/update/:id", func(c *gin.Context) {
        id := c.Param("id")
        updates := map[string]interface{}{}
        for _, f := range ec.Fields {
            if f.Name == "id" {
                continue
            }
            updates[f.Name] = c.PostForm(f.Name)
        }
        db.Table(ec.Table).
            Where("id = ?", id).
            Updates(updates)

        // conserver contexte
        redirect := prefix + "?page=" + c.Query("page") +
            "&pageSize=" + c.Query("pageSize") +
            "&sort=" + c.Query("sort") +
            "&order=" + c.Query("order")
        c.Redirect(http.StatusSeeOther, redirect)
    })

    // DELETE
    r.POST(prefix+"/delete/:id", func(c *gin.Context) {
        db.Table(ec.Table).
            Where("id = ?", c.Param("id")).
            Delete(nil)
        c.Redirect(http.StatusSeeOther, prefix)
    })
}
